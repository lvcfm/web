<?php  class alipay_notify { var $OSWAP_b6f52549b0403b44c7c58b9c61730657; var $OSWAP_4c7549253fe2bb229268fc0850c4c624urity_code; var $OSWAP_d0f10e202084d9108ef4d19cff7d634ener; var $OSWAP_222a3b0b58e91fc32a6982d46825ce9c; var $OSWAP_8dff050ed37fb975511e282dadad9585; var $OSWAP_1b1e009cb90e35bbd086f48a07672e09; var $OSWAP_c05e61ae454f73d1bfa31857343ee642; function __construct($OSWAP_d0f10e202084d9108ef4d19cff7d634ener,$OSWAP_4c7549253fe2bb229268fc0850c4c624urity_code,$OSWAP_222a3b0b58e91fc32a6982d46825ce9c = "MD5",$OSWAP_1b1e009cb90e35bbd086f48a07672e09 = "GBK",$OSWAP_c05e61ae454f73d1bfa31857343ee642= "https") { $this->OSWAP_d0f10e202084d9108ef4d19cff7d634ener = $OSWAP_d0f10e202084d9108ef4d19cff7d634ener; $this->OSWAP_4c7549253fe2bb229268fc0850c4c624urity_code = $OSWAP_4c7549253fe2bb229268fc0850c4c624urity_code; $this->OSWAP_222a3b0b58e91fc32a6982d46825ce9c = $OSWAP_222a3b0b58e91fc32a6982d46825ce9c; $this->OSWAP_8dff050ed37fb975511e282dadad9585 = ""; $this->OSWAP_1b1e009cb90e35bbd086f48a07672e09 = $OSWAP_1b1e009cb90e35bbd086f48a07672e09 ; $this->OSWAP_c05e61ae454f73d1bfa31857343ee642 = $OSWAP_c05e61ae454f73d1bfa31857343ee642; if($this->OSWAP_c05e61ae454f73d1bfa31857343ee642 == "https") { $this->OSWAP_b6f52549b0403b44c7c58b9c61730657 = "https://www.alipay.com/cooperate/gateway.do?"; }else $this->OSWAP_b6f52549b0403b44c7c58b9c61730657 = "http://notify.alipay.com/trade/notify_query.do?"; } function notify_verify() { if($this->OSWAP_c05e61ae454f73d1bfa31857343ee642 == "https") { $OSWAP_d635dac15ba15aaa418dc65f5b0d77f8yfy_url = $this->OSWAP_b6f52549b0403b44c7c58b9c61730657. "service=notify_verify" ."&partner=" .$this->OSWAP_d0f10e202084d9108ef4d19cff7d634ener. "&notify_id=".$_POST["notify_id"]; } else { $OSWAP_d635dac15ba15aaa418dc65f5b0d77f8yfy_url = $this->OSWAP_b6f52549b0403b44c7c58b9c61730657. "partner=".$this->OSWAP_d0f10e202084d9108ef4d19cff7d634ener."&notify_id=".$_POST["notify_id"]; } $OSWAP_d635dac15ba15aaa418dc65f5b0d77f8yfy_result = $this->get_verify($OSWAP_d635dac15ba15aaa418dc65f5b0d77f8yfy_url); $OSWAP_cb5f2d7652a21df2dfc7ec2a656142d1 = $this->para_filter($_POST); $OSWAP_06b4dc89f89b08c421e92d8c36110d9a = $this->arg_sort($OSWAP_cb5f2d7652a21df2dfc7ec2a656142d1); while (list ($OSWAP_8cd231c853b1a600b781889da3054be4, $OSWAP_684baa3df6b637ff5dfd6c1a9e2646d9) = each ($OSWAP_06b4dc89f89b08c421e92d8c36110d9a)) { $OSWAP_1ba53367ee8b1f0fe3a82b8b899e53a6.=$OSWAP_8cd231c853b1a600b781889da3054be4."=".$OSWAP_684baa3df6b637ff5dfd6c1a9e2646d9."&"; } $OSWAP_23465636407b42d05e781859bb39a218 = substr($OSWAP_1ba53367ee8b1f0fe3a82b8b899e53a6,0,count($OSWAP_1ba53367ee8b1f0fe3a82b8b899e53a6)-2); $this->OSWAP_8dff050ed37fb975511e282dadad9585 = $this->sign($OSWAP_23465636407b42d05e781859bb39a218.$this->OSWAP_4c7549253fe2bb229268fc0850c4c624urity_code); if (preg_match("true$",$OSWAP_d635dac15ba15aaa418dc65f5b0d77f8yfy_result) && $this->OSWAP_8dff050ed37fb975511e282dadad9585 == $_POST["sign"]) { return true; } else return false; } function return_verify() { $OSWAP_e4ddd9d8182696c4580e293c2e917b8a= $this->arg_sort($_GET); while (list ($OSWAP_8cd231c853b1a600b781889da3054be4, $OSWAP_684baa3df6b637ff5dfd6c1a9e2646d9) = each ($OSWAP_e4ddd9d8182696c4580e293c2e917b8a)) { if($OSWAP_8cd231c853b1a600b781889da3054be4 != "sign" && $OSWAP_8cd231c853b1a600b781889da3054be4 != "sign_type") $OSWAP_1ba53367ee8b1f0fe3a82b8b899e53a6.=$OSWAP_8cd231c853b1a600b781889da3054be4."=".$OSWAP_684baa3df6b637ff5dfd6c1a9e2646d9."&"; } $OSWAP_23465636407b42d05e781859bb39a218 = substr($OSWAP_1ba53367ee8b1f0fe3a82b8b899e53a6,0,count($OSWAP_1ba53367ee8b1f0fe3a82b8b899e53a6)-2); $this->OSWAP_8dff050ed37fb975511e282dadad9585 = $this->sign($OSWAP_23465636407b42d05e781859bb39a218.$this->OSWAP_4c7549253fe2bb229268fc0850c4c624urity_code); if ($this->OSWAP_8dff050ed37fb975511e282dadad9585 == $_GET["sign"]) return true; else return false; } function get_verify($OSWAP_468a02129e10c8b9197aa1d7a3a9d1c0,$OSWAP_6ba979e6b227f24d5f0c926873bdb573_out = "60") { $OSWAP_468a02129e10c8b9197aa1d7a3a9d1c0arr = parse_url($OSWAP_468a02129e10c8b9197aa1d7a3a9d1c0); $OSWAP_19d2758332fb1b43d892d9fd26b18b19 = ""; $OSWAP_cf431a984f32dbe994fd3949a98dc652 = ""; $OSWAP_c05e61ae454f73d1bfa31857343ee642s = ""; if($OSWAP_468a02129e10c8b9197aa1d7a3a9d1c0arr["scheme"] == "https") { $OSWAP_c05e61ae454f73d1bfa31857343ee642s = "ssl://"; $OSWAP_468a02129e10c8b9197aa1d7a3a9d1c0arr["port"] = "443"; } else { $OSWAP_c05e61ae454f73d1bfa31857343ee642s = "tcp://"; $OSWAP_468a02129e10c8b9197aa1d7a3a9d1c0arr["port"] = "80"; } $fp=@fsockopen($OSWAP_c05e61ae454f73d1bfa31857343ee642s . $OSWAP_468a02129e10c8b9197aa1d7a3a9d1c0arr['host'],$OSWAP_468a02129e10c8b9197aa1d7a3a9d1c0arr['port'],$OSWAP_19d2758332fb1b43d892d9fd26b18b19,$OSWAP_cf431a984f32dbe994fd3949a98dc652,$OSWAP_6ba979e6b227f24d5f0c926873bdb573_out); if(!$fp) { die("ERROR: $OSWAP_19d2758332fb1b43d892d9fd26b18b19 - $OSWAP_cf431a984f32dbe994fd3949a98dc652<br />\n"); } else { fputs($fp, "POST ".$OSWAP_468a02129e10c8b9197aa1d7a3a9d1c0arr["path"]." HTTP/1.1\r\n"); fputs($fp, "Host: ".$OSWAP_468a02129e10c8b9197aa1d7a3a9d1c0arr["host"]."\r\n"); fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n"); fputs($fp, "Content-length: ".strlen($OSWAP_468a02129e10c8b9197aa1d7a3a9d1c0arr["query"])."\r\n"); fputs($fp, "Connection: close\r\n\r\n"); fputs($fp, $OSWAP_468a02129e10c8b9197aa1d7a3a9d1c0arr["query"] . "\r\n\r\n"); while(!feof($fp)) { $OSWAP_ead5a2668d8b67d4a819f31bac723007[]=@fgets($fp, 1024); } fclose($fp); $OSWAP_ead5a2668d8b67d4a819f31bac723007 = implode(",",$OSWAP_ead5a2668d8b67d4a819f31bac723007); while (list ($OSWAP_8cd231c853b1a600b781889da3054be4, $OSWAP_684baa3df6b637ff5dfd6c1a9e2646d9) = each ($_POST)) { $OSWAP_1ba53367ee8b1f0fe3a82b8b899e53a6.=$OSWAP_8cd231c853b1a600b781889da3054be4."=".$OSWAP_684baa3df6b637ff5dfd6c1a9e2646d9."&"; } return $OSWAP_ead5a2668d8b67d4a819f31bac723007; } } function arg_sort($OSWAP_dc23547f8371ec2d2ec35e158ce3a926) { ksort($OSWAP_dc23547f8371ec2d2ec35e158ce3a926); reset($OSWAP_dc23547f8371ec2d2ec35e158ce3a926); return $OSWAP_dc23547f8371ec2d2ec35e158ce3a926; } function sign($OSWAP_23465636407b42d05e781859bb39a218) { $OSWAP_2817fb4b41af122cc645a1f901c3ae4f=''; if($this->OSWAP_222a3b0b58e91fc32a6982d46825ce9c == 'MD5') { $OSWAP_2817fb4b41af122cc645a1f901c3ae4f = md5($OSWAP_23465636407b42d05e781859bb39a218); }elseif($this->OSWAP_222a3b0b58e91fc32a6982d46825ce9c =='DSA') { die("DSA 签名方法待后续开发，请先使用MD5签名方式"); }else { die("支付宝暂不支持".$this->OSWAP_222a3b0b58e91fc32a6982d46825ce9c."类型的签名方式"); } return $OSWAP_2817fb4b41af122cc645a1f901c3ae4f; } function para_filter($OSWAP_6020c5872d61677cc53e7da021e725d7) { $OSWAP_200250e3bce3096a4c756400dd3cddbc = array(); while (list ($OSWAP_8cd231c853b1a600b781889da3054be4, $OSWAP_684baa3df6b637ff5dfd6c1a9e2646d9) = each ($OSWAP_6020c5872d61677cc53e7da021e725d7)) { if($OSWAP_8cd231c853b1a600b781889da3054be4 == "sign" || $OSWAP_8cd231c853b1a600b781889da3054be4 == "sign_type" || $OSWAP_684baa3df6b637ff5dfd6c1a9e2646d9 == "")continue; else $OSWAP_200250e3bce3096a4c756400dd3cddbc[$OSWAP_8cd231c853b1a600b781889da3054be4] = $OSWAP_6020c5872d61677cc53e7da021e725d7[$OSWAP_8cd231c853b1a600b781889da3054be4]; } return $OSWAP_200250e3bce3096a4c756400dd3cddbc; } function charset_encode($OSWAP_0a4e27b314f08113446caf533f126d56,$OSWAP_f5793af0cc680e9e33edfad0fc89354a ,$OSWAP_1b1e009cb90e35bbd086f48a07672e09 ="utf-8" ) { $OSWAP_3a2ae081867295aabc2530a498d84dfd = ""; if(!isset($OSWAP_f5793af0cc680e9e33edfad0fc89354a) )$OSWAP_f5793af0cc680e9e33edfad0fc89354a = $this->OSWAP_6020c5872d61677cc53e7da021e725d7['_input_charset']; if($OSWAP_1b1e009cb90e35bbd086f48a07672e09 == $OSWAP_f5793af0cc680e9e33edfad0fc89354a || $OSWAP_0a4e27b314f08113446caf533f126d56 ==null ) { $OSWAP_3a2ae081867295aabc2530a498d84dfd = $OSWAP_0a4e27b314f08113446caf533f126d56; } elseif (function_exists("mb_convert_encoding")){ $OSWAP_3a2ae081867295aabc2530a498d84dfd = mb_convert_encoding($OSWAP_0a4e27b314f08113446caf533f126d56,$OSWAP_f5793af0cc680e9e33edfad0fc89354a,$OSWAP_1b1e009cb90e35bbd086f48a07672e09); } elseif(function_exists("iconv")) { $OSWAP_3a2ae081867295aabc2530a498d84dfd = iconv($OSWAP_1b1e009cb90e35bbd086f48a07672e09,$OSWAP_f5793af0cc680e9e33edfad0fc89354a,$OSWAP_0a4e27b314f08113446caf533f126d56); } else die("sorry, you have no libs support for charset change."); return $OSWAP_3a2ae081867295aabc2530a498d84dfd; } function charset_decode($OSWAP_0a4e27b314f08113446caf533f126d56,$OSWAP_1b1e009cb90e35bbd086f48a07672e09 ,$OSWAP_f5793af0cc680e9e33edfad0fc89354a="utf-8" ) { $OSWAP_3a2ae081867295aabc2530a498d84dfd = ""; if(!isset($OSWAP_1b1e009cb90e35bbd086f48a07672e09) )$OSWAP_1b1e009cb90e35bbd086f48a07672e09 = $this->OSWAP_1b1e009cb90e35bbd086f48a07672e09 ; if($OSWAP_1b1e009cb90e35bbd086f48a07672e09 == $OSWAP_f5793af0cc680e9e33edfad0fc89354a || $OSWAP_0a4e27b314f08113446caf533f126d56 ==null ) { $OSWAP_3a2ae081867295aabc2530a498d84dfd = $OSWAP_0a4e27b314f08113446caf533f126d56; } elseif (function_exists("mb_convert_encoding")){ $OSWAP_3a2ae081867295aabc2530a498d84dfd = mb_convert_encoding($OSWAP_0a4e27b314f08113446caf533f126d56,$OSWAP_f5793af0cc680e9e33edfad0fc89354a,$OSWAP_1b1e009cb90e35bbd086f48a07672e09); } elseif(function_exists("iconv")) { $OSWAP_3a2ae081867295aabc2530a498d84dfd = iconv($OSWAP_1b1e009cb90e35bbd086f48a07672e09,$OSWAP_f5793af0cc680e9e33edfad0fc89354a,$OSWAP_0a4e27b314f08113446caf533f126d56); } else die("sorry, you have no libs support for charset changes."); return $OSWAP_3a2ae081867295aabc2530a498d84dfd; } } $OSWAP_b6f52549b0403b44c7c58b9c61730657module = "alipay"; $OSWAP_1b1e009cb90e35bbd086f48a07672e09 = "utf-8"; $OSWAP_222a3b0b58e91fc32a6982d46825ce9c = "MD5"; $OSWAP_c05e61ae454f73d1bfa31857343ee642 = plug_eva('alipay','transport'); $OSWAP_b6f52549b0403b44c7c58b9c61730657PID = plug_eva('alipay','partnerID'); $OSWAP_b6f52549b0403b44c7c58b9c61730657SELLER_EMAIL = plug_eva('alipay','seller_email'); $OSWAP_b6f52549b0403b44c7c58b9c61730657SECURITY_CODE = plug_eva('alipay','security_code'); $OSWAP_3a60d79ba9f961a3b2075ca3f1966eeb = new alipay_notify($OSWAP_b6f52549b0403b44c7c58b9c61730657PID,$OSWAP_b6f52549b0403b44c7c58b9c61730657SECURITY_CODE,$OSWAP_222a3b0b58e91fc32a6982d46825ce9c,$OSWAP_1b1e009cb90e35bbd086f48a07672e09,$OSWAP_c05e61ae454f73d1bfa31857343ee642); $OSWAP_d635dac15ba15aaa418dc65f5b0d77f8ify_result = $OSWAP_3a60d79ba9f961a3b2075ca3f1966eeb->return_verify(); if($OSWAP_d635dac15ba15aaa418dc65f5b0d77f8ify_result) { $OSWAP_4525c0dfc8cf6ec4e8495f8e5692f50e = $_GET['trade_status']; $OSWAP_819bc67440e6652781118a5624625fd3 = $_GET['out_trade_no']; $OSWAP_f8601b3e31917fe727087e700fb1da1e = $_GET['trade_no']; $OSWAP_394e7e76a9fdbfc46856caaddfee332d = $_GET['total_fee']; $OSWAP_d22d5ec074823d2518abf461215e5358 = 0; if($OSWAP_4525c0dfc8cf6ec4e8495f8e5692f50e == 'TRADE_FINISHED' || $OSWAP_4525c0dfc8cf6ec4e8495f8e5692f50e == 'TRADE_SUCCESS') { Pay::order_success($OSWAP_819bc67440e6652781118a5624625fd3); } } ?>
<!DOCTYPE html> 
<html> 
<head> 
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
	<title>支付宝支付页面</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://apps.bdimg.com/libs/bootstrap/3.3.4/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<style>
body {
	padding-top: 60px;
	padding-bottom: 40px;
	font-family: 'HanHei SC', 'PingFang SC', 'Helvetica Neue', 'Helvetica', 'STHeitiSC-Light', 'Arial', sans-serif;
}
.well {
	padding: 0;
	box-shadow: none;
	border-color: #E4E4E4;
	background-color: #FFF;
}
.header {
	padding: 30px 50px;
}
.logo {
	font-size: 28px;
	margin: 0;
	line-height: 30px;
	font-weight: 300;
	font-family: Raleway, sans-serif;
}
.content {
	padding: 30px;
	border-top: 1px solid #E3E3E3;
	border-bottom: 1px solid #E3E3E3;
	background-color: #F8F9FB;
}
.content h2 {
	font-weight: 300;
}
.footer {
	padding: 30px 50px;
}
.footer p {
	color: #222;
	font-size: 16px;
	line-height: 26px;
	font-weight: 300;
}
.footer p span {
	color: #777;
}

.btn {
	color: #444;
	font-size: 16px;
	font-weight: 300;
	margin-top: 30px;
	border-radius: 3px;
	border-color: #E2E7EB;
	background-color: #E2E7EB;
}
.btn:hover {
	color: #777;
	border-color: #E2E7EB;
	background-color: #E2E7EB;
}

.sa-icon.sa-success {
    border-color: #A5DC86;
}
.sa-icon {
    width: 80px;
    height: 80px;
    border: 4px solid gray;
    -webkit-border-radius: 40px;
    border-radius: 40px;
    border-radius: 50%;
    margin: 20px auto;
    padding: 0;
    position: relative;
    box-sizing: content-box;
}
.sa-icon.sa-success .sa-line.sa-tip {
    -ms-transform: rotate(45deg) \9;
}
.sa-icon.sa-success .sa-line.sa-tip {
    width: 25px;
    left: 14px;
    top: 46px;
    -webkit-transform: rotate(45deg);
    transform: rotate(45deg);
}
.sa-icon.sa-success .sa-line.sa-long {
    width: 47px;
    right: 8px;
    top: 38px;
    -webkit-transform: rotate(-45deg);
    transform: rotate(-45deg);
}
.sa-icon.sa-success .sa-line {
    height: 5px;
    background-color: #A5DC86;
    display: block;
    border-radius: 2px;
    position: absolute;
    z-index: 2;
}
.animateSuccessTip {
    -webkit-animation: animateSuccessTip 0.75s;
    animation: animateSuccessTip 0.75s;
}
.animateSuccessLong {
    -webkit-animation: animateSuccessLong 0.75s;
    animation: animateSuccessLong 0.75s;
}
.sa-icon.sa-success .sa-placeholder {
    width: 80px;
    height: 80px;
    border: 4px solid rgba(165, 220, 134, 0.2);
    -webkit-border-radius: 40px;
    border-radius: 40px;
    border-radius: 50%;
    box-sizing: content-box;
    position: absolute;
    left: -4px;
    top: -4px;
    z-index: 2;
}
.sa-icon.sa-error {
    border-color: #F27474;
}
.sa-icon.sa-error .sa-x-mark {
    position: relative;
    display: block;
}
.sa-icon.sa-error .sa-line {
    position: absolute;
    height: 5px;
    width: 47px;
    background-color: #F27474;
    display: block;
    top: 37px;
    border-radius: 2px;
}
.sa-icon.sa-error .sa-line.sa-left {
    -webkit-transform: rotate(45deg);
    transform: rotate(45deg);
    left: 17px;
}
.sa-icon.sa-error .sa-line.sa-right {
    -webkit-transform: rotate(-45deg);
    transform: rotate(-45deg);
    right: 16px;
}
@-webkit-keyframes animateSuccessTip {
    0% {
        width: 0;
        left: 1px;
        top: 19px;
    }
    54% {
        width: 0;
        left: 1px;
        top: 19px;
    }
    70% {
        width: 50px;
        left: -8px;
        top: 37px;
    }
    84% {
        width: 17px;
        left: 21px;
        top: 48px;
    }
    100% {
        width: 25px;
        left: 14px;
        top: 45px;
    }
}
@keyframes animateSuccessTip {
    0% {
        width: 0;
        left: 1px;
        top: 19px;
    }
    54% {
        width: 0;
        left: 1px;
        top: 19px;
    }
    70% {
        width: 50px;
        left: -8px;
        top: 37px;
    }
    84% {
        width: 17px;
        left: 21px;
        top: 48px;
    }
    100% {
        width: 25px;
        left: 14px;
        top: 45px;
    }
}
@-webkit-keyframes animateSuccessLong {
    0% {
        width: 0;
        right: 46px;
        top: 54px;
    }
    65% {
        width: 0;
        right: 46px;
        top: 54px;
    }
    84% {
        width: 55px;
        right: 0px;
        top: 35px;
    }
    100% {
        width: 47px;
        right: 8px;
        top: 38px;
    }
}
@keyframes animateSuccessLong {
    0% {
        width: 0;
        right: 46px;
        top: 54px;
    }
    65% {
        width: 0;
        right: 46px;
        top: 54px;
    }
    84% {
        width: 55px;
        right: 0px;
        top: 35px;
    }
    100% {
        width: 47px;
        right: 8px;
        top: 38px;
    }
}
@-webkit-keyframes animateErrorIcon {
    0% {
        transform: rotateX(100deg);
        -webkit-transform: rotateX(100deg);
        opacity: 0;
    }
    100% {
        transform: rotateX(0deg);
        -webkit-transform: rotateX(0deg);
        opacity: 1;
    }
}
@keyframes animateErrorIcon {
    0% {
        transform: rotateX(100deg);
        -webkit-transform: rotateX(100deg);
        opacity: 0;
    }
    100% {
        transform: rotateX(0deg);
        -webkit-transform: rotateX(0deg);
        opacity: 1;
    }
}
.animateErrorIcon {
    -webkit-animation: animateErrorIcon 0.5s;
    animation: animateErrorIcon 0.5s;
}
@-webkit-keyframes animateXMark {
    0% {
        transform: scale(0.4);
        -webkit-transform: scale(0.4);
        margin-top: 26px;
        opacity: 0;
    }
    50% {
        transform: scale(0.4);
        -webkit-transform: scale(0.4);
        margin-top: 26px;
        opacity: 0;
    }
    80% {
        transform: scale(1.15);
        -webkit-transform: scale(1.15);
        margin-top: -6px;
    }
    100% {
        transform: scale(1);
        -webkit-transform: scale(1);
        margin-top: 0;
        opacity: 1;
    }
}
@keyframes animateXMark {
    0% {
        transform: scale(0.4);
        -webkit-transform: scale(0.4);
        margin-top: 26px;
        opacity: 0;
    }
    50% {
        transform: scale(0.4);
        -webkit-transform: scale(0.4);
        margin-top: 26px;
        opacity: 0;
    }
    80% {
        transform: scale(1.15);
        -webkit-transform: scale(1.15);
        margin-top: -6px;
    }
    100% {
        transform: scale(1);
        -webkit-transform: scale(1);
        margin-top: 0;
        opacity: 1;
    }
}
.animateXMark {
    -webkit-animation: animateXMark 0.5s;
    animation: animateXMark 0.5s;
}
</style>
</head> 
<body>
<div class="container">
	<div class="row">
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
			<div class="well">
				<div class="header">
					<h1 class="logo"><?php echo _C('网站名称'); ?></h1>
				</div>
				<div class="content">
					<div class="row">
						<div class="col-sm-12">
	<?php if($OSWAP_4525c0dfc8cf6ec4e8495f8e5692f50e == 'TRADE_FINISHED' || $OSWAP_4525c0dfc8cf6ec4e8495f8e5692f50e == 'TRADE_SUCCESS') {?>
							<div class="sa-icon sa-success animate">
								<span class="sa-line sa-tip animateSuccessTip"></span>
								<span class="sa-line sa-long animateSuccessLong"></span>
								<div class="sa-placeholder"></div>
								<div class="sa-fix"></div>
						    </div>
	<?php } else {?>
							<div class="sa-icon sa-error animateErrorIcon">
								<span class="sa-x-mark animateXMark">
									<span class="sa-line sa-left"></span>
									<span class="sa-line sa-right"></span>
								</span>
							</div>
	<?php }?>
						</div>
						<div class="col-sm-12 text-center">
	<?php if($OSWAP_4525c0dfc8cf6ec4e8495f8e5692f50e == 'TRADE_FINISHED' || $OSWAP_4525c0dfc8cf6ec4e8495f8e5692f50e == 'TRADE_SUCCESS') {?>
							<h2>您已成功支付 <?php echo $OSWAP_394e7e76a9fdbfc46856caaddfee332d; ?> CNY </h2>
	<?php } else {?>
							<h2>奥...好像那里出错了</h2>
	<?php }?>
						</div>
					</div>
				</div>
				<div class="footer">
	<?php if($OSWAP_4525c0dfc8cf6ec4e8495f8e5692f50e == 'TRADE_FINISHED' || $OSWAP_4525c0dfc8cf6ec4e8495f8e5692f50e == 'TRADE_SUCCESS') {?>
					<p>交易编号：<span><?php echo $OSWAP_f8601b3e31917fe727087e700fb1da1e ?></span></p>
					<p>请检查充值账单是否到账。</p>
	<?php } else {?>
					<p class="text-center">貌似是什么地方出了一些问题！</p>
	<?php }?>
					<a href="/index.php/user/pay/" class="btn btn-lg btn-success btn-block">返回用户中心</a>
				</div>
			</div>
		</div>
	</div>
</div>
</body> 
</html>