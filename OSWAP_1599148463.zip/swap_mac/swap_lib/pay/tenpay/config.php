<?php
return array(
	'plug' => 'tenpay',
	'name' => '财付通',
	'version' => '1.0',
);
?>