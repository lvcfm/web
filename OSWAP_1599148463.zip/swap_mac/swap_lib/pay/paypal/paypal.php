<?php  function paypal_show(){ $configarray = array( 'plug' => 'paypal', 'name' => 'PayPal', 'text' => '国际最大支付平台，安全保障、支付自如！', 'icon' => 'paypal-icon', ); return $configarray; } function paypal_config() { $configarray = array( "paypal帐户" => array("FriendlyName" => "PayPal帐户", "Type" => "text", "Size" => "32", ), "sandbox调试模式" => array("FriendlyName" => "SandBox调试模式", "Type" => "yesno", ), ); return $configarray; } function paypal_link($OSWAP_a4904fb91faddb0fad70482a6968f75d,$OSWAP_819bc67440e6652781118a5624625fd3) { global $swap_mac; $OSWAP_2fe654e476cae7761bcec1510c0732bd = $OSWAP_819bc67440e6652781118a5624625fd3; $OSWAP_103864d0f1c4907cafc86e7b62382f14=$swap_mac['c']['网站名称']; $OSWAP_2461c819d6b20cf75774c053d1ff955c = plug_eva('paypal','paypal帐户'); $OSWAP_859670bd92882e52185dc8a76536e103 = plug_eva('paypal','sandbox调试模式'); $OSWAP_e95493392d3673a61a34bd1187b95dea=plug_eva('paypal','货币后缀'); if($OSWAP_859670bd92882e52185dc8a76536e103){ $OSWAP_468a02129e10c8b9197aa1d7a3a9d1c0='https://www.sandbox.paypal.com/cgi-bin/webscr'; }else{ $OSWAP_468a02129e10c8b9197aa1d7a3a9d1c0='https://www.paypal.com/cgi-bin/webscr'; } $OSWAP_d83f230d51e41e3295f5aa3e57501910_url="http://".$_SERVER['SERVER_NAME']."/index.php/user/pay/"; $OSWAP_c728e51cdbc1b859008318d2ed5a0df2="http://".$_SERVER['SERVER_NAME']."/index.php/pay/page/paypal/notify/"; $OSWAP_32eb8fef33a98a723ac4f40d8f67ad8c="http://".$_SERVER['SERVER_NAME']."/index.php/user/pay/"; $OSWAP_223c1f830c4ff3b888c767feb76f8bd0_text=<<<SWAP
<form action="{$OSWAP_468a02129e10c8b9197aa1d7a3a9d1c0}" name="paypalform" method="post">
<input type="hidden" name="business" value="{$OSWAP_2461c819d6b20cf75774c053d1ff955c}">
<input type="hidden" name="item_name" value="{$OSWAP_103864d0f1c4907cafc86e7b62382f14}充值账单">
<input type="hidden" name="amount" value="{$OSWAP_a4904fb91faddb0fad70482a6968f75d}">
<input type="hidden" name="no_note" value="1">
<input type="hidden" name="return"  value="{$OSWAP_d83f230d51e41e3295f5aa3e57501910_url}">
<input type="hidden" name="cancel_return" value="{$OSWAP_32eb8fef33a98a723ac4f40d8f67ad8c}">
<input type="hidden" name="custom" value="{$OSWAP_2fe654e476cae7761bcec1510c0732bd}">
<input type="hidden" name="notify_url" value="{$OSWAP_c728e51cdbc1b859008318d2ed5a0df2}">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="currency_code" value="{$OSWAP_e95493392d3673a61a34bd1187b95dea}">
<input type="hidden" name="charset" value="utf-8" />
<input type="hidden" name="rm" value="1" />
</form>
<script type="text/javascript">
document.paypalform.submit();
</script>
SWAP;
 return $OSWAP_223c1f830c4ff3b888c767feb76f8bd0_text; } 