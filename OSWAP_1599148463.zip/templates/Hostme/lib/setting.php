<?php  if (!function_exists('templateasz')) { function templateasz($OSWAP_218ad42b878c46dab0fdc437af798c13,$nr){ if($nr==""){$nr=" ";} $nr=str_replace('\"','"',$nr); $nr=str_replace("\\\\","\\",$nr); plug_eva('template_Hostme',$OSWAP_218ad42b878c46dab0fdc437af798c13,$nr); } } if (!function_exists('templateadu')) { function templateadu($OSWAP_218ad42b878c46dab0fdc437af798c13){ $OSWAP_d83f230d51e41e3295f5aa3e57501910=plug_eva('template_Hostme',$OSWAP_218ad42b878c46dab0fdc437af798c13); return $OSWAP_d83f230d51e41e3295f5aa3e57501910; } } function template_Hostme(){ echo '<div id="main-wrapper" class="container"><div class="row"><div class="col-md-12"><div class="panel panel-primary"><div class="panel-body"><form class="form-horizontal form-groups-bordered" method="post"><input type="hidden" name="ok" value="ok">'; $OSWAP_fd233d6cf7022a7f2c13b93aecdfdd8det=_GET('reset'); $ok=_POST('ok'); if($OSWAP_fd233d6cf7022a7f2c13b93aecdfdd8det!="" && $ok!="ok"){ plug_eva('template_Hostme',$OSWAP_fd233d6cf7022a7f2c13b93aecdfdd8det,null); $OSWAP_779d694f57ce70f52ed99da19b2231252=SWAP_TEMPLATES_ROOT.'/lib/main.php'; if(file_exists($OSWAP_779d694f57ce70f52ed99da19b2231252)!=false){require($OSWAP_779d694f57ce70f52ed99da19b2231252);} } $OSWAP_779d694f57ce70f52ed99da19b223125=SWAP_TEMPLATES_ROOT.'/lib/setting_config.php'; if(file_exists($OSWAP_779d694f57ce70f52ed99da19b223125)==false){echo '配置文件不存在';} require($OSWAP_779d694f57ce70f52ed99da19b223125); if($ok=="ok"){ foreach( $template_config as $OSWAP_f2e986814ae69df7dd12fcd0ffefd082 => $OSWAP_5352abd67c287b8a92c6591dc7c6d0f5){ templateasz($OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['name'],_POST($OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['name'])); } echo '<script type="text/javascript">
		alert("模板设置修改成功");
		</script>'; } foreach( $template_config as $OSWAP_f2e986814ae69df7dd12fcd0ffefd082 => $OSWAP_5352abd67c287b8a92c6591dc7c6d0f5){ $OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['value']=templateadu($OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['name']); if($OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['type']=='text'){ $OSWAP_c651f9c0ca7166f44642571878e40634=<<<SWAP
			 <input type="{$OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['type']}" value="{$OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['value']}" name="{$OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['name']}" class="form-control">
SWAP;
 }elseif($OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['type']=='yesno' ){ if($OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['value']=='yes') $OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['yes_yesno']='checked="checked"'; else $OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['no_yesno']='checked="checked"'; $OSWAP_c651f9c0ca7166f44642571878e40634=<<<SWAP
			<input type="radio" name="{$OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['name']}" value="yes"{$OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['yes_yesno']}/ class="form-control">是 
		<input type="radio" name="{$OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['name']}" value="no" {$OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['no_yesno']} class="form-control"/>否 
SWAP;
 }elseif( $OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['type']=='texts' ){ $OSWAP_c651f9c0ca7166f44642571878e40634=<<<SWAP
			<textarea name="{$OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['name']}"  style="height:120px;"  class="form-control">{$OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['value']}</textarea>
			<a href="?reset={$OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['name']}">点此恢复默认内容</a> 
SWAP;
 }elseif($OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['type']=='txt'){ $OSWAP_c651f9c0ca7166f44642571878e40634=""; }elseif( $OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['type']=='a'){ $OSWAP_c651f9c0ca7166f44642571878e40634=<<<SWAP
			
SWAP;
 }else{ $OSWAP_c651f9c0ca7166f44642571878e40634=<<<SWAP
			{$OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['type']}-{$OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['value']}
SWAP;
 } $OSWAP_5e7aa583206fe7c726012b73edc12858=<<<SWAP
		<div class="form-group">
						<label class="col-sm-3 control-label">{$OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['name']}</label>
						<div class="col-sm-5">
						{$OSWAP_c651f9c0ca7166f44642571878e40634}{$OSWAP_5352abd67c287b8a92c6591dc7c6d0f5['description']}
						</div>
					</div>
SWAP;
 echo($OSWAP_5e7aa583206fe7c726012b73edc12858); } echo '<div class="form-group">
						<div class="col-sm-offset-3 col-sm-5">
							<input type="submit" value="保存更改" class="btn btn-info"/>
						</div>
					</div></form></div></div></div></div></div>'; } add_swap_plug('模版设置','template_Hostme'); 