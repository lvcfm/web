<?php  $lang=array(); $lang=array( '首页最多显示主机产品数'=>3,'首页显示主机产品分类id'=>'1', '图标1标题'=>'主机方案灵活自由升级', '图标1内容'=>'灵活选择自己合适的主机套餐方案，在以后的时间里您可以根据自己的需要升级它.', '图标2标题'=>'服务单时效响应', '图标2内容'=>'我们保证您提交给我们的技术部门的服务单主机问题响应时间最长不超过120分钟. ', '图标3标题'=>'无忧网站转移', '图标3内容'=>'不会迁移网站？不用担心，我们提供免费网站迁移服务帮助您快速迁入', '图标4标题'=>'虚拟主机控制面板', '图标4内容'=>'我们的管理面板 功能强大，最容易使用，因而 非常受用户欢迎。 用户可以通过它轻松完成所有虚拟主机功能 操作', '现在注册前面那句话'=>'多年运维经验保障,较低的价格，领先的主机面板，您可以得到较高的性价比！<span>我们不够完美，但值得您选择！</span>', '客户名1'=>'KE XIN, Superxin', '客户名2'=>'Shao bin, BootSkin', '客户名3'=>'Zhang boran, vmpanel', '客户评价1'=>'建站菜鸟，搭建使用没有多久的Wordpress 个人博客，目前使用6个月，很不错，对于我这个初学者，完全够用啦，这个网站帮了我很大的忙呢！各种服务器的情况都有短信和邮件通知挺负责的，他们还是值得信赖的。希望越来越好成长。', '客户评价2'=>'使用这家已经差不多1年之久，几乎没有发生什么较大的问题，价格也很实惠。总体来说比较稳定，速度也很快，总是让人比较安心。提交服务单的小问题都很快答复.总之性价比还是比较高的！', '客户评价3'=>'主机价格便宜，速度也不慢，而且长期比较问题，使用半年以来发生的问题很少，性价比非常高。提交支持单回复速度也很快。赞！！！', '为什么要选择我们内容'=>'
<p>
运行超过4年虚拟主机服务商，你会得到个人网站，商务托管或电子商务托管解决方案快速，方便地启动和运行你的各种网站Web应用程序。我们的服务对象涵盖从小型企业，WP爱好者，中小站长提供服务。我们使用最新技术，优质的主机线路，优质的服务。我们的价格走着经济实惠的路线。我们不吹嘘我们的服务器，您只需花费很少的费用得到最大的结果和服务。

<h5 class="margintop">同类最佳的可靠性、 性能和价值</h5>
<p>主机点评网2014十佳主机商, 99% 在线率保障 周期性数据异地备份,免费网站搬家服务,免费程序安装服务,7天全额退款服务,24小时服务单支持,无需复杂备案流程,自助开通.实时开通,多数据中心选择,中文控制面板,方便易用,灵活升级，可扩展</p>', '自定义html'=>' <!-- CONTENT SLIDER -->      
<div class="homeslider">
<div class="row">
<div class="twelve columns">

<div class="flexslider">
          <ul class="slides">
            <li>
            <div class="row">
            <div class="seven columns">
  	    	    <img src="\templates\xiaohe_blackcloud/images/slider/slide1.png" alt="" />
            </div>
              <div class="five columns right">    
                <div class="flex-caption">
                <h2>遍及全球的主机</h2>
                 <ul>
      <li>芝加哥, <span>美国</span></li>
      <li>阿姆斯特丹, <span>荷兰</span></li>
      <li>肯特郡, <span>英国</span></li>
      <li>新加坡, <span>亚洲</span></li>
      </ul>
                
                </div>
                </div>
                </div>
  	    		</li>
                
                <li>
            <div class="row">
            <div class="seven columns">
  	    	    <img src="\templates\xiaohe_blackcloud/images/slider/slide2.png" alt="" />
            </div>
              <div class="five columns right">    
                <div class="flex-caption">
                <h2>服务器需求</h2>
                 <ul>
      <li>开通服务只需几分钟</li>
      <li>强大的图表分析软件</li>
      <li>快速的资源部署能力</li>
      <li>及时的硬件服务平台</li>
      </ul>
                
                </div>
                </div>
                </div>
  	    		</li>
                
       <li>
            <div class="row">
            <div class="six columns">
  	    	    <img src="\templates\xiaohe_blackcloud/images/slider/slide3.png" alt="" />
            </div>
              <div class="five columns right">    
                <div class="flex-caption">

                <h2>无与伦比的支持</h2>
                 <ul>
      <li><span>24X7</span>在线支持</li>
      <li>专业的<span> 专家团队</span></li>
      <li>完整的<span> 硬件支持</span></li>
      <li><span>安全的</span> 性能增强</li>
      </ul>
                
                </div>
                </div>
                </div>
  	    		</li>          
  	    		
                
          </ul>
        </div>
</div>
</div>
</div>
<!-- END OF CONTENT SLIDER -->', ''=>'', ''=>'', ''=>'', ''=>'', ''=>'', );