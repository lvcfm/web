<?php  class alipay_notify { var $OSWAP_e04d1b43738b9b907214a285a8087d98; var $OSWAP_32d80962f82ba1974d0061801a175ceaurity_code; var $OSWAP_438c3f605a7dd09e10b627a2733fdc22ner; var $OSWAP_3523713acd2b5703bcf21cd4590bc77f; var $OSWAP_d6ed462c5e09e40dbb8491e9aed203fc; var $OSWAP_eee99c108cd4a41720f6782463d5a608; var $OSWAP_39771e30fae67cf0bf3eaa26e682c7ae; function __construct($OSWAP_438c3f605a7dd09e10b627a2733fdc22ner,$OSWAP_32d80962f82ba1974d0061801a175ceaurity_code,$OSWAP_3523713acd2b5703bcf21cd4590bc77f = "MD5",$OSWAP_eee99c108cd4a41720f6782463d5a608 = "GBK",$OSWAP_39771e30fae67cf0bf3eaa26e682c7ae= "https") { $this->OSWAP_438c3f605a7dd09e10b627a2733fdc22ner = $OSWAP_438c3f605a7dd09e10b627a2733fdc22ner; $this->OSWAP_32d80962f82ba1974d0061801a175ceaurity_code = $OSWAP_32d80962f82ba1974d0061801a175ceaurity_code; $this->OSWAP_3523713acd2b5703bcf21cd4590bc77f = $OSWAP_3523713acd2b5703bcf21cd4590bc77f; $this->OSWAP_d6ed462c5e09e40dbb8491e9aed203fc = ""; $this->OSWAP_eee99c108cd4a41720f6782463d5a608 = $OSWAP_eee99c108cd4a41720f6782463d5a608 ; $this->OSWAP_39771e30fae67cf0bf3eaa26e682c7ae = $OSWAP_39771e30fae67cf0bf3eaa26e682c7ae; if($this->OSWAP_39771e30fae67cf0bf3eaa26e682c7ae == "https") { $this->OSWAP_e04d1b43738b9b907214a285a8087d98 = "https://www.alipay.com/cooperate/gateway.do?"; }else $this->OSWAP_e04d1b43738b9b907214a285a8087d98 = "http://notify.alipay.com/trade/notify_query.do?"; } function notify_verify() { if($this->OSWAP_39771e30fae67cf0bf3eaa26e682c7ae == "https") { $OSWAP_c9d7fcb0046b05e24d2f80bcf5494539yfy_url = $this->OSWAP_e04d1b43738b9b907214a285a8087d98. "service=notify_verify" ."&partner=" .$this->OSWAP_438c3f605a7dd09e10b627a2733fdc22ner. "&notify_id=".$_POST["notify_id"]; } else { $OSWAP_c9d7fcb0046b05e24d2f80bcf5494539yfy_url = $this->OSWAP_e04d1b43738b9b907214a285a8087d98. "partner=".$this->OSWAP_438c3f605a7dd09e10b627a2733fdc22ner."&notify_id=".$_POST["notify_id"]; } $OSWAP_c9d7fcb0046b05e24d2f80bcf5494539yfy_result = $this->get_verify($OSWAP_c9d7fcb0046b05e24d2f80bcf5494539yfy_url); $OSWAP_ff3eaf4893c8aa427471c2d504408696 = $this->para_filter($_POST); $OSWAP_1e142747b00087da3afcb4848e63ee53 = $this->arg_sort($OSWAP_ff3eaf4893c8aa427471c2d504408696); while (list ($OSWAP_b24b1920ce93a29c7dccede1f27ddb72, $OSWAP_4d9209c099b3a1870bc75b3f588a0dc0) = each ($OSWAP_1e142747b00087da3afcb4848e63ee53)) { $OSWAP_dc10ddda0d110c7a1a290d7081e8a576.=$OSWAP_b24b1920ce93a29c7dccede1f27ddb72."=".$OSWAP_4d9209c099b3a1870bc75b3f588a0dc0."&"; } $OSWAP_631bb3bffb404a124e507ad38f107f45 = substr($OSWAP_dc10ddda0d110c7a1a290d7081e8a576,0,count($OSWAP_dc10ddda0d110c7a1a290d7081e8a576)-2); $this->OSWAP_d6ed462c5e09e40dbb8491e9aed203fc = $this->sign($OSWAP_631bb3bffb404a124e507ad38f107f45.$this->OSWAP_32d80962f82ba1974d0061801a175ceaurity_code); if (preg_match("true$",$OSWAP_c9d7fcb0046b05e24d2f80bcf5494539yfy_result) && $this->OSWAP_d6ed462c5e09e40dbb8491e9aed203fc == $_POST["sign"]) { return true; } else return false; } function return_verify() { $OSWAP_5da2bdb968583c7fc00ccfdaddcc043f= $this->arg_sort($_GET); while (list ($OSWAP_b24b1920ce93a29c7dccede1f27ddb72, $OSWAP_4d9209c099b3a1870bc75b3f588a0dc0) = each ($OSWAP_5da2bdb968583c7fc00ccfdaddcc043f)) { if($OSWAP_b24b1920ce93a29c7dccede1f27ddb72 != "sign" && $OSWAP_b24b1920ce93a29c7dccede1f27ddb72 != "sign_type") $OSWAP_dc10ddda0d110c7a1a290d7081e8a576.=$OSWAP_b24b1920ce93a29c7dccede1f27ddb72."=".$OSWAP_4d9209c099b3a1870bc75b3f588a0dc0."&"; } $OSWAP_631bb3bffb404a124e507ad38f107f45 = substr($OSWAP_dc10ddda0d110c7a1a290d7081e8a576,0,count($OSWAP_dc10ddda0d110c7a1a290d7081e8a576)-2); $this->OSWAP_d6ed462c5e09e40dbb8491e9aed203fc = $this->sign($OSWAP_631bb3bffb404a124e507ad38f107f45.$this->OSWAP_32d80962f82ba1974d0061801a175ceaurity_code); if ($this->OSWAP_d6ed462c5e09e40dbb8491e9aed203fc == $_GET["sign"]) return true; else return false; } function get_verify($OSWAP_21dfacd18239368058aabcd1df82e72f,$OSWAP_7171c6e1a91ea9c194b5aa05d54db65b_out = "60") { $OSWAP_21dfacd18239368058aabcd1df82e72farr = parse_url($OSWAP_21dfacd18239368058aabcd1df82e72f); $OSWAP_2cd4f190f7e56adef836352ba1b9817e = ""; $OSWAP_580dfdb28e6f92aa6ff5ce23bdc14da1 = ""; $OSWAP_39771e30fae67cf0bf3eaa26e682c7aes = ""; if($OSWAP_21dfacd18239368058aabcd1df82e72farr["scheme"] == "https") { $OSWAP_39771e30fae67cf0bf3eaa26e682c7aes = "ssl://"; $OSWAP_21dfacd18239368058aabcd1df82e72farr["port"] = "443"; } else { $OSWAP_39771e30fae67cf0bf3eaa26e682c7aes = "tcp://"; $OSWAP_21dfacd18239368058aabcd1df82e72farr["port"] = "80"; } $fp=@fsockopen($OSWAP_39771e30fae67cf0bf3eaa26e682c7aes . $OSWAP_21dfacd18239368058aabcd1df82e72farr['host'],$OSWAP_21dfacd18239368058aabcd1df82e72farr['port'],$OSWAP_2cd4f190f7e56adef836352ba1b9817e,$OSWAP_580dfdb28e6f92aa6ff5ce23bdc14da1,$OSWAP_7171c6e1a91ea9c194b5aa05d54db65b_out); if(!$fp) { die("ERROR: $OSWAP_2cd4f190f7e56adef836352ba1b9817e - $OSWAP_580dfdb28e6f92aa6ff5ce23bdc14da1<br />\n"); } else { fputs($fp, "POST ".$OSWAP_21dfacd18239368058aabcd1df82e72farr["path"]." HTTP/1.1\r\n"); fputs($fp, "Host: ".$OSWAP_21dfacd18239368058aabcd1df82e72farr["host"]."\r\n"); fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n"); fputs($fp, "Content-length: ".strlen($OSWAP_21dfacd18239368058aabcd1df82e72farr["query"])."\r\n"); fputs($fp, "Connection: close\r\n\r\n"); fputs($fp, $OSWAP_21dfacd18239368058aabcd1df82e72farr["query"] . "\r\n\r\n"); while(!feof($fp)) { $OSWAP_3fe3c4ba43bba3781e7532cec9b607a3[]=@fgets($fp, 1024); } fclose($fp); $OSWAP_3fe3c4ba43bba3781e7532cec9b607a3 = implode(",",$OSWAP_3fe3c4ba43bba3781e7532cec9b607a3); while (list ($OSWAP_b24b1920ce93a29c7dccede1f27ddb72, $OSWAP_4d9209c099b3a1870bc75b3f588a0dc0) = each ($_POST)) { $OSWAP_dc10ddda0d110c7a1a290d7081e8a576.=$OSWAP_b24b1920ce93a29c7dccede1f27ddb72."=".$OSWAP_4d9209c099b3a1870bc75b3f588a0dc0."&"; } return $OSWAP_3fe3c4ba43bba3781e7532cec9b607a3; } } function arg_sort($OSWAP_80298627eb2fa9682d941bbb19317183) { ksort($OSWAP_80298627eb2fa9682d941bbb19317183); reset($OSWAP_80298627eb2fa9682d941bbb19317183); return $OSWAP_80298627eb2fa9682d941bbb19317183; } function sign($OSWAP_631bb3bffb404a124e507ad38f107f45) { $OSWAP_87ef3961dd3494cf791cbdecf13b7f8f=''; if($this->OSWAP_3523713acd2b5703bcf21cd4590bc77f == 'MD5') { $OSWAP_87ef3961dd3494cf791cbdecf13b7f8f = md5($OSWAP_631bb3bffb404a124e507ad38f107f45); }elseif($this->OSWAP_3523713acd2b5703bcf21cd4590bc77f =='DSA') { die("DSA 签名方法待后续开发，请先使用MD5签名方式"); }else { die("支付宝暂不支持".$this->OSWAP_3523713acd2b5703bcf21cd4590bc77f."类型的签名方式"); } return $OSWAP_87ef3961dd3494cf791cbdecf13b7f8f; } function para_filter($OSWAP_9b2c161a325110a25cd3d1567a1e7b6b) { $OSWAP_c18e660c87c5dd2092f599f87352f896 = array(); while (list ($OSWAP_b24b1920ce93a29c7dccede1f27ddb72, $OSWAP_4d9209c099b3a1870bc75b3f588a0dc0) = each ($OSWAP_9b2c161a325110a25cd3d1567a1e7b6b)) { if($OSWAP_b24b1920ce93a29c7dccede1f27ddb72 == "sign" || $OSWAP_b24b1920ce93a29c7dccede1f27ddb72 == "sign_type" || $OSWAP_4d9209c099b3a1870bc75b3f588a0dc0 == "")continue; else $OSWAP_c18e660c87c5dd2092f599f87352f896[$OSWAP_b24b1920ce93a29c7dccede1f27ddb72] = $OSWAP_9b2c161a325110a25cd3d1567a1e7b6b[$OSWAP_b24b1920ce93a29c7dccede1f27ddb72]; } return $OSWAP_c18e660c87c5dd2092f599f87352f896; } function charset_encode($OSWAP_07f0f5d51dba37b0fa5a42f9fd43e69c,$OSWAP_0e7a238c29ce766493e8bd87d49581fd ,$OSWAP_eee99c108cd4a41720f6782463d5a608 ="utf-8" ) { $OSWAP_3322686913204c4d6ea9bdcde49dcc7e = ""; if(!isset($OSWAP_0e7a238c29ce766493e8bd87d49581fd) )$OSWAP_0e7a238c29ce766493e8bd87d49581fd = $this->OSWAP_9b2c161a325110a25cd3d1567a1e7b6b['_input_charset']; if($OSWAP_eee99c108cd4a41720f6782463d5a608 == $OSWAP_0e7a238c29ce766493e8bd87d49581fd || $OSWAP_07f0f5d51dba37b0fa5a42f9fd43e69c ==null ) { $OSWAP_3322686913204c4d6ea9bdcde49dcc7e = $OSWAP_07f0f5d51dba37b0fa5a42f9fd43e69c; } elseif (function_exists("mb_convert_encoding")){ $OSWAP_3322686913204c4d6ea9bdcde49dcc7e = mb_convert_encoding($OSWAP_07f0f5d51dba37b0fa5a42f9fd43e69c,$OSWAP_0e7a238c29ce766493e8bd87d49581fd,$OSWAP_eee99c108cd4a41720f6782463d5a608); } elseif(function_exists("iconv")) { $OSWAP_3322686913204c4d6ea9bdcde49dcc7e = iconv($OSWAP_eee99c108cd4a41720f6782463d5a608,$OSWAP_0e7a238c29ce766493e8bd87d49581fd,$OSWAP_07f0f5d51dba37b0fa5a42f9fd43e69c); } else die("sorry, you have no libs support for charset change."); return $OSWAP_3322686913204c4d6ea9bdcde49dcc7e; } function charset_decode($OSWAP_07f0f5d51dba37b0fa5a42f9fd43e69c,$OSWAP_eee99c108cd4a41720f6782463d5a608 ,$OSWAP_0e7a238c29ce766493e8bd87d49581fd="utf-8" ) { $OSWAP_3322686913204c4d6ea9bdcde49dcc7e = ""; if(!isset($OSWAP_eee99c108cd4a41720f6782463d5a608) )$OSWAP_eee99c108cd4a41720f6782463d5a608 = $this->OSWAP_eee99c108cd4a41720f6782463d5a608 ; if($OSWAP_eee99c108cd4a41720f6782463d5a608 == $OSWAP_0e7a238c29ce766493e8bd87d49581fd || $OSWAP_07f0f5d51dba37b0fa5a42f9fd43e69c ==null ) { $OSWAP_3322686913204c4d6ea9bdcde49dcc7e = $OSWAP_07f0f5d51dba37b0fa5a42f9fd43e69c; } elseif (function_exists("mb_convert_encoding")){ $OSWAP_3322686913204c4d6ea9bdcde49dcc7e = mb_convert_encoding($OSWAP_07f0f5d51dba37b0fa5a42f9fd43e69c,$OSWAP_0e7a238c29ce766493e8bd87d49581fd,$OSWAP_eee99c108cd4a41720f6782463d5a608); } elseif(function_exists("iconv")) { $OSWAP_3322686913204c4d6ea9bdcde49dcc7e = iconv($OSWAP_eee99c108cd4a41720f6782463d5a608,$OSWAP_0e7a238c29ce766493e8bd87d49581fd,$OSWAP_07f0f5d51dba37b0fa5a42f9fd43e69c); } else die("sorry, you have no libs support for charset changes."); return $OSWAP_3322686913204c4d6ea9bdcde49dcc7e; } } $OSWAP_e04d1b43738b9b907214a285a8087d98module = "alipay"; $OSWAP_eee99c108cd4a41720f6782463d5a608 = "utf-8"; $OSWAP_3523713acd2b5703bcf21cd4590bc77f = "MD5"; $OSWAP_39771e30fae67cf0bf3eaa26e682c7ae = plug_eva('alipay','transport'); $OSWAP_e04d1b43738b9b907214a285a8087d98PID = plug_eva('alipay','partnerID'); $OSWAP_e04d1b43738b9b907214a285a8087d98SELLER_EMAIL = plug_eva('alipay','seller_email'); $OSWAP_e04d1b43738b9b907214a285a8087d98SECURITY_CODE = plug_eva('alipay','security_code'); $OSWAP_a54420cf7eb414d4b071a1f6bb0f1f68 = new alipay_notify($OSWAP_e04d1b43738b9b907214a285a8087d98PID,$OSWAP_e04d1b43738b9b907214a285a8087d98SECURITY_CODE,$OSWAP_3523713acd2b5703bcf21cd4590bc77f,$OSWAP_eee99c108cd4a41720f6782463d5a608,$OSWAP_39771e30fae67cf0bf3eaa26e682c7ae); $OSWAP_c9d7fcb0046b05e24d2f80bcf5494539ify_result = $OSWAP_a54420cf7eb414d4b071a1f6bb0f1f68->return_verify(); if($OSWAP_c9d7fcb0046b05e24d2f80bcf5494539ify_result) { $OSWAP_07df22dfdbc0a492be39d18fe67565e7 = $_GET['trade_status']; $OSWAP_eef964b9198a343d472d6b2b405b6423 = $_GET['out_trade_no']; $OSWAP_faeebcbd07b67a5f749f972346c3de9a = $_GET['trade_no']; $OSWAP_e6473bdf732e319ecaa14bfcdce5a80c = $_GET['total_fee']; $OSWAP_57a07ddf35da099bc14aa32cc6214517 = 0; if($OSWAP_07df22dfdbc0a492be39d18fe67565e7 == 'TRADE_FINISHED' || $OSWAP_07df22dfdbc0a492be39d18fe67565e7 == 'TRADE_SUCCESS') { Pay::order_success($OSWAP_eef964b9198a343d472d6b2b405b6423); } } ?>
<!DOCTYPE html> 
<html> 
<head> 
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
	<title>支付宝支付页面</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://apps.bdimg.com/libs/bootstrap/3.3.4/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<style>
body {
	padding-top: 60px;
	padding-bottom: 40px;
	font-family: 'HanHei SC', 'PingFang SC', 'Helvetica Neue', 'Helvetica', 'STHeitiSC-Light', 'Arial', sans-serif;
}
.well {
	padding: 0;
	box-shadow: none;
	border-color: #E4E4E4;
	background-color: #FFF;
}
.header {
	padding: 30px 50px;
}
.logo {
	font-size: 28px;
	margin: 0;
	line-height: 30px;
	font-weight: 300;
	font-family: Raleway, sans-serif;
}
.content {
	padding: 30px;
	border-top: 1px solid #E3E3E3;
	border-bottom: 1px solid #E3E3E3;
	background-color: #F8F9FB;
}
.content h2 {
	font-weight: 300;
}
.footer {
	padding: 30px 50px;
}
.footer p {
	color: #222;
	font-size: 16px;
	line-height: 26px;
	font-weight: 300;
}
.footer p span {
	color: #777;
}

.btn {
	color: #444;
	font-size: 16px;
	font-weight: 300;
	margin-top: 30px;
	border-radius: 3px;
	border-color: #E2E7EB;
	background-color: #E2E7EB;
}
.btn:hover {
	color: #777;
	border-color: #E2E7EB;
	background-color: #E2E7EB;
}

.sa-icon.sa-success {
    border-color: #A5DC86;
}
.sa-icon {
    width: 80px;
    height: 80px;
    border: 4px solid gray;
    -webkit-border-radius: 40px;
    border-radius: 40px;
    border-radius: 50%;
    margin: 20px auto;
    padding: 0;
    position: relative;
    box-sizing: content-box;
}
.sa-icon.sa-success .sa-line.sa-tip {
    -ms-transform: rotate(45deg) \9;
}
.sa-icon.sa-success .sa-line.sa-tip {
    width: 25px;
    left: 14px;
    top: 46px;
    -webkit-transform: rotate(45deg);
    transform: rotate(45deg);
}
.sa-icon.sa-success .sa-line.sa-long {
    width: 47px;
    right: 8px;
    top: 38px;
    -webkit-transform: rotate(-45deg);
    transform: rotate(-45deg);
}
.sa-icon.sa-success .sa-line {
    height: 5px;
    background-color: #A5DC86;
    display: block;
    border-radius: 2px;
    position: absolute;
    z-index: 2;
}
.animateSuccessTip {
    -webkit-animation: animateSuccessTip 0.75s;
    animation: animateSuccessTip 0.75s;
}
.animateSuccessLong {
    -webkit-animation: animateSuccessLong 0.75s;
    animation: animateSuccessLong 0.75s;
}
.sa-icon.sa-success .sa-placeholder {
    width: 80px;
    height: 80px;
    border: 4px solid rgba(165, 220, 134, 0.2);
    -webkit-border-radius: 40px;
    border-radius: 40px;
    border-radius: 50%;
    box-sizing: content-box;
    position: absolute;
    left: -4px;
    top: -4px;
    z-index: 2;
}
.sa-icon.sa-error {
    border-color: #F27474;
}
.sa-icon.sa-error .sa-x-mark {
    position: relative;
    display: block;
}
.sa-icon.sa-error .sa-line {
    position: absolute;
    height: 5px;
    width: 47px;
    background-color: #F27474;
    display: block;
    top: 37px;
    border-radius: 2px;
}
.sa-icon.sa-error .sa-line.sa-left {
    -webkit-transform: rotate(45deg);
    transform: rotate(45deg);
    left: 17px;
}
.sa-icon.sa-error .sa-line.sa-right {
    -webkit-transform: rotate(-45deg);
    transform: rotate(-45deg);
    right: 16px;
}
@-webkit-keyframes animateSuccessTip {
    0% {
        width: 0;
        left: 1px;
        top: 19px;
    }
    54% {
        width: 0;
        left: 1px;
        top: 19px;
    }
    70% {
        width: 50px;
        left: -8px;
        top: 37px;
    }
    84% {
        width: 17px;
        left: 21px;
        top: 48px;
    }
    100% {
        width: 25px;
        left: 14px;
        top: 45px;
    }
}
@keyframes animateSuccessTip {
    0% {
        width: 0;
        left: 1px;
        top: 19px;
    }
    54% {
        width: 0;
        left: 1px;
        top: 19px;
    }
    70% {
        width: 50px;
        left: -8px;
        top: 37px;
    }
    84% {
        width: 17px;
        left: 21px;
        top: 48px;
    }
    100% {
        width: 25px;
        left: 14px;
        top: 45px;
    }
}
@-webkit-keyframes animateSuccessLong {
    0% {
        width: 0;
        right: 46px;
        top: 54px;
    }
    65% {
        width: 0;
        right: 46px;
        top: 54px;
    }
    84% {
        width: 55px;
        right: 0px;
        top: 35px;
    }
    100% {
        width: 47px;
        right: 8px;
        top: 38px;
    }
}
@keyframes animateSuccessLong {
    0% {
        width: 0;
        right: 46px;
        top: 54px;
    }
    65% {
        width: 0;
        right: 46px;
        top: 54px;
    }
    84% {
        width: 55px;
        right: 0px;
        top: 35px;
    }
    100% {
        width: 47px;
        right: 8px;
        top: 38px;
    }
}
@-webkit-keyframes animateErrorIcon {
    0% {
        transform: rotateX(100deg);
        -webkit-transform: rotateX(100deg);
        opacity: 0;
    }
    100% {
        transform: rotateX(0deg);
        -webkit-transform: rotateX(0deg);
        opacity: 1;
    }
}
@keyframes animateErrorIcon {
    0% {
        transform: rotateX(100deg);
        -webkit-transform: rotateX(100deg);
        opacity: 0;
    }
    100% {
        transform: rotateX(0deg);
        -webkit-transform: rotateX(0deg);
        opacity: 1;
    }
}
.animateErrorIcon {
    -webkit-animation: animateErrorIcon 0.5s;
    animation: animateErrorIcon 0.5s;
}
@-webkit-keyframes animateXMark {
    0% {
        transform: scale(0.4);
        -webkit-transform: scale(0.4);
        margin-top: 26px;
        opacity: 0;
    }
    50% {
        transform: scale(0.4);
        -webkit-transform: scale(0.4);
        margin-top: 26px;
        opacity: 0;
    }
    80% {
        transform: scale(1.15);
        -webkit-transform: scale(1.15);
        margin-top: -6px;
    }
    100% {
        transform: scale(1);
        -webkit-transform: scale(1);
        margin-top: 0;
        opacity: 1;
    }
}
@keyframes animateXMark {
    0% {
        transform: scale(0.4);
        -webkit-transform: scale(0.4);
        margin-top: 26px;
        opacity: 0;
    }
    50% {
        transform: scale(0.4);
        -webkit-transform: scale(0.4);
        margin-top: 26px;
        opacity: 0;
    }
    80% {
        transform: scale(1.15);
        -webkit-transform: scale(1.15);
        margin-top: -6px;
    }
    100% {
        transform: scale(1);
        -webkit-transform: scale(1);
        margin-top: 0;
        opacity: 1;
    }
}
.animateXMark {
    -webkit-animation: animateXMark 0.5s;
    animation: animateXMark 0.5s;
}
</style>
</head> 
<body>
<div class="container">
	<div class="row">
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
			<div class="well">
				<div class="header">
					<h1 class="logo"><?php echo _C('网站名称'); ?></h1>
				</div>
				<div class="content">
					<div class="row">
						<div class="col-sm-12">
	<?php if($OSWAP_07df22dfdbc0a492be39d18fe67565e7 == 'TRADE_FINISHED' || $OSWAP_07df22dfdbc0a492be39d18fe67565e7 == 'TRADE_SUCCESS') {?>
							<div class="sa-icon sa-success animate">
								<span class="sa-line sa-tip animateSuccessTip"></span>
								<span class="sa-line sa-long animateSuccessLong"></span>
								<div class="sa-placeholder"></div>
								<div class="sa-fix"></div>
						    </div>
	<?php } else {?>
							<div class="sa-icon sa-error animateErrorIcon">
								<span class="sa-x-mark animateXMark">
									<span class="sa-line sa-left"></span>
									<span class="sa-line sa-right"></span>
								</span>
							</div>
	<?php }?>
						</div>
						<div class="col-sm-12 text-center">
	<?php if($OSWAP_07df22dfdbc0a492be39d18fe67565e7 == 'TRADE_FINISHED' || $OSWAP_07df22dfdbc0a492be39d18fe67565e7 == 'TRADE_SUCCESS') {?>
							<h2>您已成功支付 <?php echo $OSWAP_e6473bdf732e319ecaa14bfcdce5a80c; ?> CNY </h2>
	<?php } else {?>
							<h2>奥...好像那里出错了</h2>
	<?php }?>
						</div>
					</div>
				</div>
				<div class="footer">
	<?php if($OSWAP_07df22dfdbc0a492be39d18fe67565e7 == 'TRADE_FINISHED' || $OSWAP_07df22dfdbc0a492be39d18fe67565e7 == 'TRADE_SUCCESS') {?>
					<p>交易编号：<span><?php echo $OSWAP_faeebcbd07b67a5f749f972346c3de9a ?></span></p>
					<p>请检查充值账单是否到账。</p>
	<?php } else {?>
					<p class="text-center">貌似是什么地方出了一些问题！</p>
	<?php }?>
					<a href="/index.php/user/pay/" class="btn btn-lg btn-success btn-block">返回用户中心</a>
				</div>
			</div>
		</div>
	</div>
</div>
</body> 
</html>