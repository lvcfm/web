<?php  function paypal_show(){ $configarray = array( 'plug' => 'paypal', 'name' => 'PayPal', 'text' => '国际最大支付平台，安全保障、支付自如！', 'icon' => 'paypal-icon', ); return $configarray; } function paypal_config() { $configarray = array( "paypal帐户" => array("FriendlyName" => "PayPal帐户", "Type" => "text", "Size" => "32", ), "sandbox调试模式" => array("FriendlyName" => "SandBox调试模式", "Type" => "yesno", ), ); return $configarray; } function paypal_link($OSWAP_be95c0dacce4fd5a241f070ab98e9b66,$OSWAP_eef964b9198a343d472d6b2b405b6423) { global $swap_mac; $OSWAP_f3efb755e410147164481b75d26744b7 = $OSWAP_eef964b9198a343d472d6b2b405b6423; $OSWAP_a9fd9d518ff0dc0fc0fa3d66d8d2855b=$swap_mac['c']['网站名称']; $OSWAP_8f05e49a763edad342ab759fb47d9c06 = plug_eva('paypal','paypal帐户'); $OSWAP_39f410536656ecd11ef30439a9b8a4e3 = plug_eva('paypal','sandbox调试模式'); $OSWAP_76a1969173877a0c7afe4c14aa210663=plug_eva('paypal','货币后缀'); if($OSWAP_39f410536656ecd11ef30439a9b8a4e3){ $OSWAP_21dfacd18239368058aabcd1df82e72f='https://www.sandbox.paypal.com/cgi-bin/webscr'; }else{ $OSWAP_21dfacd18239368058aabcd1df82e72f='https://www.paypal.com/cgi-bin/webscr'; } $OSWAP_e75de14e73e9665a99e7eaeb21ca4cdb_url="http://".$_SERVER['SERVER_NAME']."/index.php/user/pay/"; $OSWAP_8bd40d1c6c67a724b31bee8786582235="http://".$_SERVER['SERVER_NAME']."/index.php/pay/page/paypal/notify/"; $OSWAP_248e69c7adbdba7d0fb403b40c074d94="http://".$_SERVER['SERVER_NAME']."/index.php/user/pay/"; $OSWAP_586da5eb51820488655f74036e5a08e4_text=<<<SWAP
<form action="{$OSWAP_21dfacd18239368058aabcd1df82e72f}" name="paypalform" method="post">
<input type="hidden" name="business" value="{$OSWAP_8f05e49a763edad342ab759fb47d9c06}">
<input type="hidden" name="item_name" value="{$OSWAP_a9fd9d518ff0dc0fc0fa3d66d8d2855b}充值账单">
<input type="hidden" name="amount" value="{$OSWAP_be95c0dacce4fd5a241f070ab98e9b66}">
<input type="hidden" name="no_note" value="1">
<input type="hidden" name="return"  value="{$OSWAP_e75de14e73e9665a99e7eaeb21ca4cdb_url}">
<input type="hidden" name="cancel_return" value="{$OSWAP_248e69c7adbdba7d0fb403b40c074d94}">
<input type="hidden" name="custom" value="{$OSWAP_f3efb755e410147164481b75d26744b7}">
<input type="hidden" name="notify_url" value="{$OSWAP_8bd40d1c6c67a724b31bee8786582235}">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="currency_code" value="{$OSWAP_76a1969173877a0c7afe4c14aa210663}">
<input type="hidden" name="charset" value="utf-8" />
<input type="hidden" name="rm" value="1" />
</form>
<script type="text/javascript">
document.paypalform.submit();
</script>
SWAP;
 return $OSWAP_586da5eb51820488655f74036e5a08e4_text; } 