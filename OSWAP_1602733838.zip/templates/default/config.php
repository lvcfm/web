<?php
return array(
	'name'=>'默认模版',
	'version'=>'1.0',
	'minsystemver'=>'0.2.0.0'
);
?>