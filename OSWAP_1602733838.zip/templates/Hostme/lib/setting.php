<?php  if (!function_exists('templateasz')) { function templateasz($OSWAP_b0b2b1334df5606944e705a6abf54a63,$nr){ if($nr==""){$nr=" ";} $nr=str_replace('\"','"',$nr); $nr=str_replace("\\\\","\\",$nr); plug_eva('template_Hostme',$OSWAP_b0b2b1334df5606944e705a6abf54a63,$nr); } } if (!function_exists('templateadu')) { function templateadu($OSWAP_b0b2b1334df5606944e705a6abf54a63){ $OSWAP_e75de14e73e9665a99e7eaeb21ca4cdb=plug_eva('template_Hostme',$OSWAP_b0b2b1334df5606944e705a6abf54a63); return $OSWAP_e75de14e73e9665a99e7eaeb21ca4cdb; } } function template_Hostme(){ echo '<div id="main-wrapper" class="container"><div class="row"><div class="col-md-12"><div class="panel panel-primary"><div class="panel-body"><form class="form-horizontal form-groups-bordered" method="post"><input type="hidden" name="ok" value="ok">'; $OSWAP_ed7a004f6c819f6bada43e14a06bb2c1et=_GET('reset'); $ok=_POST('ok'); if($OSWAP_ed7a004f6c819f6bada43e14a06bb2c1et!="" && $ok!="ok"){ plug_eva('template_Hostme',$OSWAP_ed7a004f6c819f6bada43e14a06bb2c1et,null); $OSWAP_286ed17e42d0bbb900c67656e5a1509b2=SWAP_TEMPLATES_ROOT.'/lib/main.php'; if(file_exists($OSWAP_286ed17e42d0bbb900c67656e5a1509b2)!=false){require($OSWAP_286ed17e42d0bbb900c67656e5a1509b2);} } $OSWAP_286ed17e42d0bbb900c67656e5a1509b=SWAP_TEMPLATES_ROOT.'/lib/setting_config.php'; if(file_exists($OSWAP_286ed17e42d0bbb900c67656e5a1509b)==false){echo '配置文件不存在';} require($OSWAP_286ed17e42d0bbb900c67656e5a1509b); if($ok=="ok"){ foreach( $template_config as $OSWAP_68f15178c2b9afb3dd36134a2bc64d44 => $OSWAP_2732a338c314adcf44e0395b1f7c165f){ templateasz($OSWAP_2732a338c314adcf44e0395b1f7c165f['name'],_POST($OSWAP_2732a338c314adcf44e0395b1f7c165f['name'])); } echo '<script type="text/javascript">
		alert("模板设置修改成功");
		</script>'; } foreach( $template_config as $OSWAP_68f15178c2b9afb3dd36134a2bc64d44 => $OSWAP_2732a338c314adcf44e0395b1f7c165f){ $OSWAP_2732a338c314adcf44e0395b1f7c165f['value']=templateadu($OSWAP_2732a338c314adcf44e0395b1f7c165f['name']); if($OSWAP_2732a338c314adcf44e0395b1f7c165f['type']=='text'){ $OSWAP_6be8043a1a2e51ca0806284d6be7fd64=<<<SWAP
			 <input type="{$OSWAP_2732a338c314adcf44e0395b1f7c165f['type']}" value="{$OSWAP_2732a338c314adcf44e0395b1f7c165f['value']}" name="{$OSWAP_2732a338c314adcf44e0395b1f7c165f['name']}" class="form-control">
SWAP;
 }elseif($OSWAP_2732a338c314adcf44e0395b1f7c165f['type']=='yesno' ){ if($OSWAP_2732a338c314adcf44e0395b1f7c165f['value']=='yes') $OSWAP_2732a338c314adcf44e0395b1f7c165f['yes_yesno']='checked="checked"'; else $OSWAP_2732a338c314adcf44e0395b1f7c165f['no_yesno']='checked="checked"'; $OSWAP_6be8043a1a2e51ca0806284d6be7fd64=<<<SWAP
			<input type="radio" name="{$OSWAP_2732a338c314adcf44e0395b1f7c165f['name']}" value="yes"{$OSWAP_2732a338c314adcf44e0395b1f7c165f['yes_yesno']}/ class="form-control">是 
		<input type="radio" name="{$OSWAP_2732a338c314adcf44e0395b1f7c165f['name']}" value="no" {$OSWAP_2732a338c314adcf44e0395b1f7c165f['no_yesno']} class="form-control"/>否 
SWAP;
 }elseif( $OSWAP_2732a338c314adcf44e0395b1f7c165f['type']=='texts' ){ $OSWAP_6be8043a1a2e51ca0806284d6be7fd64=<<<SWAP
			<textarea name="{$OSWAP_2732a338c314adcf44e0395b1f7c165f['name']}"  style="height:120px;"  class="form-control">{$OSWAP_2732a338c314adcf44e0395b1f7c165f['value']}</textarea>
			<a href="?reset={$OSWAP_2732a338c314adcf44e0395b1f7c165f['name']}">点此恢复默认内容</a> 
SWAP;
 }elseif($OSWAP_2732a338c314adcf44e0395b1f7c165f['type']=='txt'){ $OSWAP_6be8043a1a2e51ca0806284d6be7fd64=""; }elseif( $OSWAP_2732a338c314adcf44e0395b1f7c165f['type']=='a'){ $OSWAP_6be8043a1a2e51ca0806284d6be7fd64=<<<SWAP
			
SWAP;
 }else{ $OSWAP_6be8043a1a2e51ca0806284d6be7fd64=<<<SWAP
			{$OSWAP_2732a338c314adcf44e0395b1f7c165f['type']}-{$OSWAP_2732a338c314adcf44e0395b1f7c165f['value']}
SWAP;
 } $OSWAP_6eb3e152173ce5673b87f65ea7f680f6=<<<SWAP
		<div class="form-group">
						<label class="col-sm-3 control-label">{$OSWAP_2732a338c314adcf44e0395b1f7c165f['name']}</label>
						<div class="col-sm-5">
						{$OSWAP_6be8043a1a2e51ca0806284d6be7fd64}{$OSWAP_2732a338c314adcf44e0395b1f7c165f['description']}
						</div>
					</div>
SWAP;
 echo($OSWAP_6eb3e152173ce5673b87f65ea7f680f6); } echo '<div class="form-group">
						<div class="col-sm-offset-3 col-sm-5">
							<input type="submit" value="保存更改" class="btn btn-info"/>
						</div>
					</div></form></div></div></div></div></div>'; } add_swap_plug('模版设置','template_Hostme'); 